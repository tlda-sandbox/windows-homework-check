// The homework macro additions for the student zips' KaTeX render.
//
// One source file: edit here. `bin/build-handouts.py` stages this file, plus
// katex-assets/macros.js and shared/katex-course-shim.html, into every handout
// zip; the zip's yaml names all three in include-in-header, and the shim feeds
// the merged set to katex.render (pandoc's own render loop cannot take macros
// by configuration -- see the shim's header).
//
// What belongs here: only what katex-assets/macros.js does NOT already carry.
// Measured 2026-10-10: the base set already has \RMSE \E \V \sd \hVar \bias;
// it has none of the three below.
window.__tldaKatexMacros = window.__tldaKatexMacros || {};
Object.assign(window.__tldaKatexMacros, {
  "\\thetaprior": "\\theta^{\\text{prior}}",
  "\\nprior": "n^{\\text{prior}}",
  "\\yprior": "y^{\\text{prior}}",
});
