pollurl = "https://pollev.com/davidahirshberg"
lecture = function(n, id=NULL) { 
    if(is.null(id)) { 
        sprintf("https://qtm285-1.github.io/assets/lectures/Lecture%d.html", n) } 
    else { 
        sprintf("https://qtm285-1.github.io/assets/lectures/Lecture%d.html#%s", n, id)
    }
}
homework = function(n, id=NULL) { 
    if(is.null(id)) { 
        sprintf("https://qtm285-1.github.io/assets/homework/week%d-homework.html", n) } 
    else { 
        sprintf("https://qtm285-1.github.io/assets/homework/week%d-homework.html#%s", n, id)
    }
}

qtm285_document = local({ f = knitr::current_input(dir = TRUE); if (is.null(f)) NA_character_ else normalizePath(f, winslash = "/", mustWork = FALSE) })
qtm285_homework = grepl("(^|/)homework(/|$)", qtm285_document) || grepl("^homework-", basename(qtm285_document))
library(tidyverse)
library(htmltools)
library(kableExtra)
if (!qtm285_homework) library(gt)
library(scales)
library(knitr)

default.seed = 0
percent = label_percent(accuracy=1)
percentpoint = label_percent(accuracy=.1)
approx  = function(x,accuracy=.01) { 
    label_number(accuracy=accuracy, scale_cut=cut_short_scale())(x) 
}
thousand = function(x, accuracy=.1) {
    approx(round((x/1000) / accuracy) * 1000 * accuracy, accuracy)
}
round2 = function(x) { round(x, 2) }

# Helper for toggle tables in image-toggle figures
# rows: list of vectors, one per row (first element is row label)
# visible: logical vector, which rows are visible (others get class="empty")
# colors: character vector of CSS classes for each row (empty string = no color)
# header: optional header row
if (!qtm285_homework) {
toggle_table = function(rows, visible = rep(TRUE, length(rows)),
                        colors = rep("", length(rows)), header = NULL,
                        caption = NULL) {
  
  make_row = function(cells, visible, color) {
    cell_class = if (!visible) "empty" else if (color != "") color else ""
    cells_html = sapply(seq_along(cells), function(i) {
      cell = cells[[i]]
      tag = if (i == 1) 'th scope="row"' else "td"
      if (cell_class != "") {
        sprintf('<%s class="%s">%s</%s>', tag, cell_class, cell,
                if (i == 1) "th" else "td")
      } else {
        sprintf('<%s>%s</%s>', tag, cell, if (i == 1) "th" else "td")
      }
    })
    sprintf('<tr>%s</tr>', paste(cells_html, collapse = ""))
  }
  
  header_html = ""
  if (!is.null(header)) {
    header_cells = sapply(header, function(h) sprintf('<th scope="col">%s</th>', h))
    header_html = sprintf('<thead><tr>%s</tr></thead>', paste(header_cells, collapse = ""))
  }
  
  rows_html = mapply(make_row, rows, visible, colors, SIMPLIFY = TRUE)
  
  caption_html = if (is.null(caption)) "" else sprintf('<caption>%s</caption>', caption)
  sprintf('<table class="poll-table">%s%s<tbody>%s</tbody></table>',
          caption_html, header_html, paste(rows_html, collapse = ""))
}
}
