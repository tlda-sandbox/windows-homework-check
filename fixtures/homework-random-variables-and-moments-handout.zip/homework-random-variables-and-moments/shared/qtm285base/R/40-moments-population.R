markov.town.full = read.csv("data/vote-history-markov.csv")$history
markov.H = markov.town.full[1:100]
