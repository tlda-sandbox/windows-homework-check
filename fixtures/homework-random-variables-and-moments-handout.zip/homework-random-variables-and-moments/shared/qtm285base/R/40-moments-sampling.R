moments.population = c(rep(1, 40), rep(0, 60))
moments.sizes = c(5, 20, 80)
moments.sampling.distribution = function(n, mechanism) {
  if (mechanism == "With replacement") {
    estimate = (0:n)/n
    probability = dbinom(0:n, n, mean(moments.population))
  } else if (mechanism == "Without replacement") {
    estimate = (0:n)/n
    probability = dhyper(0:n, sum(moments.population),
                        length(moments.population)-sum(moments.population), n)
  } else if (mechanism == "Random-start cycle") {
    draws = sapply(seq_along(moments.population), function(start) {
      positions = ((start-1+0:(n-1)) %% length(moments.population))+1
      mean(moments.population[positions])
    })
    counts = table(draws)
    estimate = as.numeric(names(counts))
    probability = as.numeric(counts)/length(moments.population)
  } else stop("Unknown sampling mechanism: ", mechanism)
  data.frame(n=n, mechanism=mechanism, estimate=estimate, probability=probability)
}
moments.sampling = purrr::map_dfr(moments.sizes, function(n)
  purrr::map_dfr(c("With replacement", "Without replacement", "Random-start cycle"),
    function(mechanism) moments.sampling.distribution(n, mechanism)))

moments.facet.dots = function(data, panels, x, height.by, ...) {
  keys = unique(data[, panels, drop=FALSE])
  out = list()
  for (i in seq_len(nrow(keys))) {
    key = keys[i, , drop=FALSE]
    sel = rep(TRUE, nrow(data))
    for (p in panels) sel = sel & (data[[p]] == key[[p]][1])
    samples = data[[x]][sel]
    geoms = with_annotations(samples, dots=length(samples),
      height=max(data[[height.by]][sel]), ...)
    stamp = function(g) {
      if (is.list(g) && !inherits(g, "ggproto")) return(lapply(g, stamp))
      if (!is.null(g$data) && is.data.frame(g$data) && nrow(g$data)>0) {
        key.rows = key[rep(1, nrow(g$data)), , drop=FALSE]
        rownames(key.rows) = NULL
        g$data = cbind(g$data, key.rows)
      }
      g
    }
    out = c(out, lapply(geoms, stamp))
  }
  out
}
# xlim defaults to the full response range, which is what the nine-panel figure
# uses. A two-panel comparison at one sample size passes the range the
# probability actually occupies instead.
moments.sampling.plot = function(n.only=NULL, mechanisms=NULL,
                                xlim=c(-.03,1.03), breaks=c(0,.5,1)) {
  distributions = moments.sampling
  if (!is.null(n.only)) distributions = subset(distributions, n %in% n.only)
  if (!is.null(mechanisms)) distributions = subset(distributions, mechanism %in% mechanisms)
  distributions$mechanism = factor(distributions$mechanism,
    levels=c("Random-start cycle", "With replacement", "Without replacement"))
  dots = distributions |>
    dplyr::mutate(dot.count=round(400*probability)) |>
    tidyr::uncount(dot.count) |>
    dplyr::group_by(n, mechanism, estimate) |>
    dplyr::mutate(dot.height=dplyr::row_number()/400) |>
    dplyr::ungroup()
  panel.limits = aggregate(probability ~ n, moments.sampling, max)
  limits = merge(unique(distributions[c("n", "mechanism")]), panel.limits, by="n")
  ggplot(distributions, aes(x=estimate, y=probability)) +
    geom_blank(data=limits, aes(x=0, y=probability)) +
    geom_col(aes(width=pmin(.025, .8/n)), alpha=.2) +
    moments.facet.dots(dots, panels=c("n", "mechanism"), x="estimate",
      height.by="dot.height", highlight.dots=1, vline.alpha=NA,
      dot.size=.35, unhighlighted.dot.alpha=.22, seed=default.seed) +
    geom_vline(xintercept=mean(moments.population), color=green, linewidth=1.2) +
    facet_grid(n ~ mechanism, scales="free_y",
      labeller=labeller(n=function(x) paste0("n = ", x))) +
    scale_x_continuous(limits=xlim, breaks=breaks) +
    simplified.theme + theme(strip.text=element_text(size=14), axis.text=element_text(size=12))
}
