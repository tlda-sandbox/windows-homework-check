# Working variance town: 20 residents with the original proportions.
zvar.deviations = rep(c(-1.5, -1, -.5, 0, .5, 1, 1.5), c(1, 2, 4, 6, 4, 2, 1))
zvar.rowstep = 0.004
zvar.dots = data.frame(id=seq_along(zvar.deviations), z=zvar.deviations)
zvar.dots$z2 = zvar.dots$z^2
zvar.dots$zs = sign(zvar.dots$z)*zvar.dots$z^2
zvar.dots = zvar.dots[order(zvar.dots$z, zvar.dots$id), ]
zvar.dots$y_z = ave(zvar.dots$id, zvar.dots$z, FUN=function(v) seq_along(v)*zvar.rowstep)
zvar.dots = zvar.dots[order(zvar.dots$zs, zvar.dots$z, zvar.dots$id), ]
zvar.dots$y_zs = ave(zvar.dots$id, zvar.dots$zs, FUN=function(v) (seq_along(v)-.5)/20)
zvar.dots$side.col = ifelse(zvar.dots$z < 0, teal, ifelse(zvar.dots$z > 0, pink, "gray55"))
# Folded stack heights retain origin: positive red below, negative teal above.
zvar.fold.bound = c("0"=0, "0.25"=0.2, "1"=0.1, "2.25"=0.05)
zvar.dots = zvar.dots[order(zvar.dots$z2, zvar.dots$z < 0, zvar.dots$z, zvar.dots$id), ]
zvar.dots$side.rank = ave(zvar.dots$id, zvar.dots$z2, zvar.dots$z < 0,
                          FUN=function(v) seq_along(v))
zvar.dots$y_zf = (zvar.dots$side.rank-.5)/20 +
  ifelse(zvar.dots$z < 0, zvar.fold.bound[as.character(zvar.dots$z2)], 0)
zvar.variance = mean(zvar.dots$z2)

# Signed-square histogram bars: same masses as Z, relocated by sign.
zvar.signed = data.frame(x=c(-2.25, -1, -.25, 0, .25, 1, 2.25),
                         p=c(.05, .1, .2, .3, .2, .1, .05))
zvar.signed$side = ifelse(zvar.signed$x < 0, "neg", ifelse(zvar.signed$x > 0, "pos", "zero"))

# Folded Z^2 stacks: positive-side mass below, mirrored negative above.
zvar.fold = data.frame(x=c(0, .25, .25, 1, 1, 2.25, 2.25),
                       ymin=c(0, 0, .2, 0, .1, 0, .05),
                       ymax=c(.3, .2, .4, .1, .2, .05, .1),
                       side=c("zero", "pos", "neg", "pos", "neg", "pos", "neg"))

zvar.side.fill = c(neg=teal, pos=pink, zero="gray55")

zvar.center = .7
zvar.dots$Y = zvar.center + zvar.dots$z
zvar.dots$Ysigned = zvar.center + zvar.dots$zs
# The working town IS the shown 20: every resident displayed.
zvar.shown = zvar.dots[order(zvar.dots$id), ]
zvar.shown$y_arm = .018 + annotation_dot_heights(nrow(zvar.shown), 0, .33, default.seed)
zvar.axis = function() {
  list(scale_x_continuous(limits=c(-2.5, 2.5), breaks=seq(-2.5, 2.5, .5)),
       scale_y_continuous(limits=c(0, .46)), simplified.theme)
}
zvar.mean.annotation = function(value) {
  line = with_annotations(zvar.shown$z, estimand=value, dots=0,
                          highlight.dots=0, vline.alpha=NA)[[1]]
  line$aes_params$colour = green
  line$aes_params$linewidth = 1.2
  line
}
zvar.original = function() {
  ggplot(zvar.dots) +
    geom_bar(aes(x=z, y=after_stat(prop)), width=.2,
             fill="gray55", color="gray55", alpha=.2, linewidth=.4) +
    zvar.mean.annotation(0) +
    geom_point(data=zvar.shown, aes(x=z, y=y_arm),
               color="gray55", alpha=.6, size=1.1) +
    zvar.axis()
}
zvar.barbells = function() {
  list(
    geom_segment(data=zvar.shown,
      aes(x=z, xend=zs, y=y_arm, yend=y_arm, color=I(side.col)),
      linewidth=.45, alpha=.6),
    geom_point(data=zvar.shown, aes(x=z, y=y_arm),
      color="gray45", alpha=.6, size=1.1),
    geom_point(data=zvar.shown, aes(x=zs, y=y_arm, color=I(side.col)),
      alpha=.6, size=1.1))
}
zvar.original.arms = function() zvar.original() + zvar.barbells()
zvar.signed.hist = function() {
  ggplot(zvar.dots) +
    geom_col(data=zvar.signed, aes(x=x, y=p, fill=side, color=side),
             width=.2, alpha=.3, linewidth=.5) +
    scale_fill_manual(values=zvar.side.fill, guide="none") +
    scale_color_manual(values=zvar.side.fill, guide="none") +
    zvar.mean.annotation(0) +
    zvar.barbells() +
    geom_point(data=zvar.shown, aes(x=zs, y=y_zs, color=I(side.col)),
               alpha=.6, size=1.1) +
    zvar.axis()
}
zvar.folded = function() {
  ggplot(zvar.dots) +
    geom_rect(data=zvar.fold,
              aes(xmin=x-.1, xmax=x+.1, ymin=ymin, ymax=ymax,
                  fill=side, color=side), alpha=.3, linewidth=.5) +
    scale_fill_manual(values=zvar.side.fill, guide="none") +
    scale_color_manual(values=zvar.side.fill, guide="none") +
    zvar.mean.annotation(zvar.variance) +
    zvar.barbells() +
    geom_point(data=zvar.shown, aes(x=z2, y=y_zf, color=I(side.col)),
               alpha=.6, size=1.1) +
    zvar.axis()
}
zvar.plot = function(state) {
  stopifnot(state %in% 0:3)
  switch(state+1, zvar.original(), zvar.original.arms(),
         zvar.signed.hist(), zvar.folded())
}

twopop.pop = data.frame(person=c(1, 2), resp=c(0, 1))
twopop.pop.bal4 = data.frame(person=1:4, resp=c(0, 0, 1, 1))
twopop.pop.unbal = data.frame(person=1:4, resp=c(0, 0, 0, 1))

twopop.population.fig = function(resp=c(0, 1)) {
  d = data.frame(person=seq_along(resp), resp=resp)
  ggplot(d, aes(x=person, y=resp)) +
    geom_point(color="gray45", size=5) +
    # Shared limits across N=2 and N=4: identical axes/panel geometry,
    # so response-0/1 points sit at identical pixels in every case.
    # Ticks identify only extant people.
    scale_x_continuous(breaks=seq_along(resp), limits=c(0.5, 4.5)) +
    scale_y_continuous(breaks=0:1, limits=c(-0.5, 1.5)) +
    coord_fixed() +
    labs(x="person", y="response") +
    simplified.theme
}

twopop.fill.limits = c(0, 9/16)
twopop.fill.breaks = c(0, 1/4, 9/16)
twopop.fill.labels = c("0", "1/4", "9/16")
twopop.fill.scale = function(name) {
  scale_fill_gradient(low="white", high="#7756a8",
                      limits=twopop.fill.limits,
                      breaks=twopop.fill.breaks,
                      labels=twopop.fill.labels, name=name)
}

twopop.legend.name.J = "P(J1, J2)"
twopop.legend.name.Y = "P(Y1, Y2)"
twopop.legend.pads = local({
  grDevices::pdf(file=NULL)
  on.exit(grDevices::dev.off())
  grid::pushViewport(grid::viewport(gp=grid::gpar(fontsize=11)))
  wJ = grid::convertWidth(grid::stringWidth(twopop.legend.name.J),
                          "pt", valueOnly=TRUE)
  wY = grid::convertWidth(grid::stringWidth(twopop.legend.name.Y),
                          "pt", valueOnly=TRUE)
  grid::popViewport()
  c(J=max(0, wY - wJ), Y=max(0, wJ - wY))
})
twopop.legend.pad.theme = function(name) {
  pad = if (name == twopop.legend.name.J) twopop.legend.pads[["J"]]
        else twopop.legend.pads[["Y"]]
  # Slightly smaller title plus space above the bar clears the top tick
  # label at 2.8in height. Bottom margins are equal across cases, so the
  # height lock is unaffected.
  theme(legend.title=element_text(size=rel(.85),
                                  margin=margin(b=6, r=pad, unit="pt")))
}

twopop.calls = expand.grid(J1=c(1, 2), J2=c(1, 2))
twopop.calls$p = 1/4
stopifnot(all(twopop.calls$p == 1/4), sum(twopop.calls$p) == 1)

twopop.calls.fig = function(n=2) {
  stopifnot(n %in% c(2, 4))
  calls = expand.grid(J1=seq_len(n), J2=seq_len(n))
  calls$p = 1/n^2
  calls$lab = paste0("1/", n^2)
  ggplot(calls, aes(x=J2, y=J1, fill=p)) +
    geom_tile(color="gray70", linewidth=.6) +
    geom_text(aes(label=lab), color="gray25", size=4) +
    scale_x_continuous(breaks=seq_len(n)) +
    scale_y_reverse(breaks=seq_len(n)) +
    twopop.fill.scale(twopop.legend.name.J) +
    coord_fixed() +
    labs(x="J2 (second call)", y="J1 (first call)") +
    simplified.theme +
    twopop.legend.pad.theme(twopop.legend.name.J)
}

twopop.resp.pairs = expand.grid(Y1=c(0, 1), Y2=c(0, 1))
twopop.resp.sum = twopop.resp.pairs$Y1 + twopop.resp.pairs$Y2
stopifnot(all(twopop.resp.sum == c(0, 1, 1, 2)))
twopop.p.balanced = rep(1/4, 4)
twopop.p.unbalanced = c(9, 3, 3, 1)/16
stopifnot(sum(twopop.p.balanced) == 1, sum(twopop.p.unbalanced) == 1)

twopop.response.fig = function(probs) {
  stopifnot(length(probs) == 4, isTRUE(all.equal(sum(probs), 1)))
  d = cbind(twopop.resp.pairs, p=probs)
  ggplot(d, aes(x=Y2, y=Y1, fill=p)) +
    geom_tile(color="gray70", linewidth=.6) +
    scale_x_continuous(breaks=0:1) +
    scale_y_reverse(breaks=0:1) +
    twopop.fill.scale(twopop.legend.name.Y) +
    coord_fixed() +
    labs(x="Y2 (second draw)", y="Y1 (first draw)") +
    simplified.theme +
    twopop.legend.pad.theme(twopop.legend.name.Y)
}

twopop.joint = cbind(twopop.resp.pairs, p=twopop.p.balanced)
twopop.joint.fig = function() twopop.response.fig(twopop.p.balanced)

twopop.sum.fig = function(masses, labels) {
  stopifnot(length(masses) == 3, length(labels) == 3, isTRUE(all.equal(sum(masses), 1)))
  d = data.frame(s=factor(0:2), p=masses, lab=labels)
  ggplot(d, aes(x=s, y=p)) +
    geom_col(fill="gray45") +
    geom_text(aes(label=lab), vjust=-0.5, color="gray30", size=5) +
    scale_y_continuous(limits=c(0, 2/3), breaks=c(0, 1/4, 1/2),
                       labels=c("0", "1/4", "1/2")) +
    labs(x="sum", y="probability") +
    simplified.theme
}
twopop.sum.balanced = c(1/4, 1/2, 1/4)
twopop.sum.balanced.lab = c("1/4", "1/2", "1/4")
twopop.sum.unbalanced = c(9/16, 6/16, 1/16)
twopop.sum.unbalanced.lab = c("9/16", "6/16", "1/16")

calls.population.fig = function() twopop.population.fig(c(0, 1))
calls.joint.fig = function() twopop.calls.fig()
pop4.bal.fig = function() twopop.population.fig(c(0, 0, 1, 1))
pop4.unbal.fig = function() twopop.population.fig(c(0, 0, 0, 1))
resp.joint.unbal.fig = function() twopop.response.fig(twopop.p.unbalanced)
sumhist.bal.fig = function() {
  twopop.sum.fig(twopop.sum.balanced, twopop.sum.balanced.lab)
}
sumhist.unbal.fig = function() {
  twopop.sum.fig(twopop.sum.unbalanced, twopop.sum.unbalanced.lab)
}

twopop.blank = ggplot() + theme_void()

twopop.response.blank.fig = function() {
  d = cbind(twopop.resp.pairs, p=NA_real_)
  fill.scale = twopop.fill.scale(twopop.legend.name.Y)
  fill.scale$na.value = "white"
  ggplot(d, aes(x=Y2, y=Y1, fill=p)) +
    geom_tile(color="gray70", linewidth=.6) +
    scale_x_continuous(breaks=0:1) +
    scale_y_reverse(breaks=0:1) +
    fill.scale + guides(fill="none") +
    coord_fixed() +
    labs(x="Y2 (second draw)", y="Y1 (first draw)") +
    simplified.theme +
    twopop.legend.pad.theme(twopop.legend.name.Y)
}

library(ggplot2)

# Shared pink/teal/simplified.theme come from the include above.
indrev.gray = "gray45"

# Four-person joint tables. With replacement: 16 cells x 1/16. Without:
# 12 off-diagonal cells x 1/12, diagonal 0. All margins 1/4 either way.
indrev.people = 1:4
indrev.grid = expand.grid(J1=indrev.people, J2=indrev.people)
indrev.grid$p_with = 1/16
indrev.grid$p_without = ifelse(indrev.grid$J1 == indrev.grid$J2, 0, 1/12)
indrev.grid$lab_with = "1/16"
indrev.grid$lab_without = ifelse(indrev.grid$J1 == indrev.grid$J2, "0", "1/12")

indrev.sr = 2  # selected row (first person)
indrev.sc = 3  # selected column (second person)

# Conditional distribution within the selected row. With replacement the
# row is unchanged (1/4 each); without, the selected person is ruled out.
indrev.cond = function(mech) {
  p = if (mech == "with") rep(1/4, 4)
      else ifelse(indrev.people == indrev.sr, 0, 1/3)
  data.frame(J2=factor(indrev.people), p=p,
             lab=if (mech == "with") "1/4"
                 else ifelse(indrev.people == indrev.sr, "0", "1/3"),
             ruledout=indrev.people == indrev.sr & mech == "without")
}

# Hatching clipped to a box. `visual` is the on-screen direction:
# "up" (/) or "down" (\). Assumes coord_fixed so data slope +-1 is 45 deg.
indrev.hatch = function(x0, x1, y0, y1, visual, step=0.18) {
  m = if (visual == "up") -1 else 1  # data slope under scale_y_reverse
  corners = c(y0 - m*x0, y0 - m*x1, y1 - m*x0, y1 - m*x1)
  out = data.frame(x=numeric(0), y=numeric(0),
                   xend=numeric(0), yend=numeric(0))
  for (b in seq(min(corners), max(corners), by=step*sqrt(2))) {
    xa = (y0 - b)/m
    xb = (y1 - b)/m
    lo = max(min(xa, xb), x0)
    hi = min(max(xa, xb), x1)
    if (hi - lo > 0.05)
      out[nrow(out) + 1, ] = c(lo, m*lo + b, hi, m*hi + b)
  }
  out
}

indrev.rowbox = list(x0=.5, x1=4.5, y0=indrev.sr - .5, y1=indrev.sr + .5)
indrev.colbox = list(x0=indrev.sc - .5, x1=indrev.sc + .5, y0=.5, y1=4.5)
indrev.rowstripes = indrev.hatch(indrev.rowbox$x0, indrev.rowbox$x1,
                                 indrev.rowbox$y0, indrev.rowbox$y1, "up")
indrev.colstripes = indrev.hatch(indrev.colbox$x0, indrev.colbox$x1,
                                 indrev.colbox$y0, indrev.colbox$y1, "down")

indrev.margins = data.frame(
  pos=indrev.people, lab="1/4",
  rowcol=ifelse(indrev.people == indrev.sr, pink, indrev.gray),
  colcol=ifelse(indrev.people == indrev.sc, teal, indrev.gray))

indrev.plot = function(mech, state) {
  stopifnot(mech %in% c("with", "without"), state %in% 0:3)
  pcol = if (mech == "with") "p_with" else "p_without"
  lcol = if (mech == "with") "lab_with" else "lab_without"
  show.row = state %in% c(1, 3)
  show.col = state %in% c(2, 3)
  p = ggplot(indrev.grid, aes(x=J2, y=J1)) +
    geom_tile(fill="white", color="gray70", linewidth=.6) +
    # Margin labels: column sums above, row sums right; selected ones colored.
    geom_text(data=indrev.margins,
              aes(x=pos, y=0.22, label=lab,
                  color=I(if (show.col) colcol else indrev.gray)), size=3.5) +
    geom_text(data=indrev.margins,
              aes(x=4.78, y=pos, label=lab,
                  color=I(if (show.row) rowcol else indrev.gray)), size=3.5) +
    scale_x_continuous(breaks=1:4, limits=c(.5, 5.6)) +
    scale_y_reverse(breaks=1:4, limits=c(5.0, 0.0)) +
    coord_fixed() +
    labs(x="J2 (second person)", y="J1 (first person)") +
    simplified.theme
  if (show.row)
    p = p +
      geom_segment(data=indrev.rowstripes,
                   aes(x=x, y=y, xend=xend, yend=yend),
                   color=pink, linewidth=.5, alpha=.75) +
      annotate("rect", xmin=indrev.rowbox$x0, xmax=indrev.rowbox$x1,
               ymin=indrev.rowbox$y0, ymax=indrev.rowbox$y1,
               fill=NA, color=pink, linewidth=1)
  if (show.col)
    p = p +
      geom_segment(data=indrev.colstripes,
                   aes(x=x, y=y, xend=xend, yend=yend),
                   color=teal, linewidth=.5, alpha=.75) +
      annotate("rect", xmin=indrev.colbox$x0, xmax=indrev.colbox$x1,
               ymin=indrev.colbox$y0, ymax=indrev.colbox$y1,
               fill=NA, color=teal, linewidth=1)
  if (state == 3)
    p = p + annotate("rect", xmin=indrev.sc - .5, xmax=indrev.sc + .5,
                     ymin=indrev.sr - .5, ymax=indrev.sr + .5,
                     fill=NA, color="gray30", linewidth=.8)
  # Probability labels last, on white backplates above the stripes.
  p = p + geom_label(aes(label=.data[[lcol]]), color="gray30", size=3.5,
                     fill="white", linewidth=0,
                     label.padding=grid::unit(0.15, "lines"))
  p
}

indrev.cond.plot = function(mech) {
  d = indrev.cond(mech)
  ggplot(d, aes(x=J2, y=p)) +
    geom_col(aes(fill=I(ifelse(ruledout, "gray80", pink))), alpha=.55) +
    geom_text(aes(label=lab, y=p + .02), color="gray30", size=5) +
    scale_y_continuous(limits=c(0, .45), breaks=c(0, .25, 1/3),
                       labels=c("0", "1/4", "1/3")) +
    labs(x="J2 given selected row", y="probability") +
    simplified.theme
}


# Markov vote-history visual: raw H/h elections voted in (0..5).
# Working town of 100 voters from frozen data/vote-history-markov.csv;
# the visible chapter setup snippet selects which 100 (currently [1:100]).
# Histogram, dots, and all calculations below describe that same town.
# Writer-free transfer bytes: deck chunks print recall/tail/step/ramp.fig.
# Deck deps: ggplot2, grid (composite), deck theme (plots add no theme).
#
# Grammar (Skip direct): gray geom_bar histogram (lecture alpha .3),
# purple data dots (with_annotations pattern, alpha .15), blue overlay
# only (indicator rect / x/t gradient, course alpha .1). No pink/teal.
# Layout per state: histogram left 2/3, step/ramp function graph right
# 1/3, same geometry through fragments, device 9x3.3.
# Dot AREA encodes value on one scale (unit size 2 = default.dot.size):
# step states 0/1, ramp H/4 (max 1.25 at H=5). Zero values keep pale
# hollow outlines at the same coordinates. Function panel marks unit 1.

# markov.H (working town, 100 voters) is defined by the visible chapter
# setup snippet, which must run BEFORE this include: it reads frozen
# data/vote-history-markov.csv and selects [1:100]. Guard what arrived.
stopifnot(length(markov.H) == 100, all(markov.H %in% 0:5),
          all(as.numeric(table(factor(markov.H, levels=0:5))) ==
                c(5, 8, 20, 28, 32, 7)),
          sum(markov.H >= 4) == 39,
          abs(mean(markov.H) - 2.95) < 1e-4)

markov.t = 4
markov.unit.size = 4
markov.dot.alpha = 1
markov.key.alpha = function(v) v*0.1
markov.key.fill = function(v) {
  grDevices::rgb(0, 0, 1, alpha=markov.key.alpha(v), maxColorValue=1)
}

# Same annotation heights as the shared lecture helper; the working town IS
# the shown 100, so every resident is displayed in every state.
markov.H100 = markov.H
markov.height = default_height(markov.H)
markov.dots = data.frame(x=markov.H100,
  y=annotation_dot_heights(100, 3, markov.height, seed=0))
markov.ymax = max(max(table(markov.H)/length(markov.H)), markov.height)*1.15

# Function values on the dots (kept names).
recall.step.v = as.numeric(markov.H100 >= markov.t)
recall.ramp.v = markov.H100/markov.t

# Area-scaled opaque dots + pale zero outlines, same coordinates.
markov.dots.layer = function(values) {
  d = data.frame(x=markov.dots$x, y=markov.dots$y, v=values)
  filled = d[d$v > 0, ]
  filled$sz = markov.unit.size*sqrt(filled$v)
  out = list(ggplot2::geom_point(data=filled,
    ggplot2::aes(x=x, y=y), size=filled$sz,
    color="gray30", alpha=markov.dot.alpha, stroke=0))
  if (any(d$v == 0))
    out[[length(out) + 1]] =
      ggplot2::geom_point(data=d[d$v == 0, ], ggplot2::aes(x=x, y=y),
        shape=1, size=markov.unit.size, stroke=.5,
        color="#bbbbbb", alpha=1)
  out
}

# Shared unit-area key (identical object, every histogram panel).
markov.unit.key = list(
  ggplot2::annotate("point", x=5.05, y=markov.ymax*0.93,
                    size=markov.unit.size, color="gray30", alpha=markov.dot.alpha, stroke=0),
  ggplot2::annotate("text", x=5.35, y=markov.ymax*0.93, label="area 1",
                    hjust=0, vjust=.5, size=4, color="gray30"))

markov.hist.base = function() {
  tick.cols = rep("#aaaaaa", 6)
  tick.cols[markov.t + 1] = "blue"
  ggplot2::ggplot() +
    ggplot2::geom_histogram(data=data.frame(H=markov.H),
      ggplot2::aes(x=H, y=ggplot2::after_stat(density)),
      binwidth=1, boundary=0.5, closed="left", fill="gray65", alpha=.7,
      color="gray45", linewidth=.4) +
    ggplot2::scale_x_continuous(breaks=0:5, expand=c(0, 0)) +
    ggplot2::coord_cartesian(xlim=c(-0.6, 5.9)) +
    ggplot2::scale_y_continuous(limits=c(0, markov.ymax), expand=c(0, 0)) +
    ggplot2::labs(x="value", y="proportion") +
    simplified.theme +
    ggplot2::theme(panel.grid.major=ggplot2::element_blank(),
      panel.grid.minor=ggplot2::element_blank(),
      axis.text.x=ggplot2::element_text(color=tick.cols))
}

markov.hist = function(values, shade=c("none", "step", "ramp")) {
  shade = match.arg(shade)
  p = markov.hist.base()
  if (shade == "step")
    p = p + ggplot2::annotate("rect", xmin=markov.t - 0.5, xmax=Inf,
      ymin=-Inf, ymax=Inf, alpha=markov.key.alpha(1), fill="blue")
  if (shade == "ramp") {
    xs = data.frame(x0=seq(-0.5, 5.5 - 6/200, length.out=200))
    xs$x1 = xs$x0 + 6/200
    xs$xmid = (xs$x0 + xs$x1)/2
    xs$v = pmax(xs$xmid/markov.t, 0)
    xs$col = markov.key.fill(xs$v)
    p = p + ggplot2::geom_rect(data=xs,
      ggplot2::aes(xmin=x0, xmax=x1, ymin=-Inf, ymax=Inf,
                   fill=I(col)))
  }
  p + markov.dots.layer(values) + markov.unit.key
}

markov.graph = function(which=c("step", "ramp")) {
  which = match.arg(which)
  tick.cols = rep("#aaaaaa", 6)
  tick.cols[markov.t + 1] = "blue"
  p = ggplot2::ggplot() +
    ggplot2::scale_x_continuous(breaks=0:5, limits=c(-0.6, 5.9),
                                expand=c(0, 0)) +
    ggplot2::scale_y_continuous(breaks=seq(0, 1.5, .5), limits=c(-.07, 1.55),
                                expand=c(0, 0)) +
    ggplot2::labs(x="value", y="function value") +
    simplified.theme +
    ggplot2::theme(panel.grid.major=ggplot2::element_blank(),
      panel.grid.minor=ggplot2::element_blank(),
      axis.text.x=ggplot2::element_text(color=tick.cols))
  if (which == "step")
    p = p +
      ggplot2::annotate("segment", x=0, xend=markov.t, y=0, yend=0,
        color="blue", linewidth=.8) +
      ggplot2::annotate("segment", x=markov.t, xend=5.9, y=1, yend=1,
        color="blue", linewidth=.8) +
      ggplot2::annotate("point", x=markov.t, y=1, size=markov.unit.size,
        color="blue") +
      ggplot2::annotate("point", x=markov.t, y=0, size=markov.unit.size,
        shape=21, fill="white", color="blue", stroke=1) +
      ggplot2::geom_point(data=data.frame(x=0:5, y=as.numeric(0:5 >= markov.t)),
        ggplot2::aes(x=x, y=y), color="gray30", size=markov.unit.size*0.75)
  else
    p = p +
      ggplot2::annotate("segment", x=0, xend=5.9, y=0, yend=5.9/markov.t,
        color="blue", linewidth=.8) +
      ggplot2::geom_point(data=data.frame(x=0:5, y=(0:5)/markov.t),
        ggplot2::aes(x=x, y=y), color="gray30", size=markov.unit.size*0.75)
  p
}

markov.compose = function(hist, graph) {
  hg = ggplot2::ggplotGrob(hist)
  gg = ggplot2::ggplotGrob(graph)
  hg$name = "history-histogram"
  gg$name = "weight-function"
  hg$vp = grid::viewport(layout.pos.col=1)
  gg$vp = grid::viewport(layout.pos.col=2)
  grid::gTree(children=grid::gList(hist=hg, graph=gg),
    vp=grid::viewport(layout=grid::grid.layout(
      nrow=1, ncol=2, widths=grid::unit(c(2, 1), "null"))))
}

# Four fragment states (recall/tail show original dots; step/ramp change their area).
recall.fig = markov.compose(
  markov.hist(rep(1, 100), "step"), markov.graph("step"))
tail.fig = markov.compose(
  markov.hist(rep(1, 100), "step"), markov.graph("step"))
step.fig = markov.compose(
  markov.hist(recall.step.v, "step"), markov.graph("step"))
ramp.fig = markov.compose(
  markov.hist(recall.ramp.v, "ramp"), markov.graph("ramp"))

markov.show = function(fig) {
  grid::grid.newpage()
  grid::grid.draw(fig)
  invisible(NULL)
}

# Chebyshev: illustrative dnorm curve with both tails beyond k=2 shaded.
# The curve is density-shaped illustration only; the bound is on combined
# tail area. No text is drawn on the plot: the slide text beside the figure
# carries the tail-event connection and the bound in matching colors.
sds.cheby.k = 2
sds.cheby.curve = data.frame(x=seq(-5, 5, length.out=1000))
sds.cheby.curve$y = dnorm(sds.cheby.curve$x)
sds.cheby.left = sds.cheby.curve[sds.cheby.curve$x <= -sds.cheby.k, ]
sds.cheby.right = sds.cheby.curve[sds.cheby.curve$x >= sds.cheby.k, ]
sds.cheby.top = max(sds.cheby.curve$y)
sds.chebyshev = function(view=c("standardized", "general", "estimator")) {
  view = match.arg(view)
  general = view == "general"
  ticks = if (view == "estimator") expression(theta-t*sigma, theta, theta+t*sigma) else
    if (general) expression(E[X]-t, E[X], E[X]+t) else c("-k", "mean", "k")
  ggplot() +
    geom_ribbon(data=sds.cheby.left, aes(x=x, ymin=0, ymax=y),
                fill=pink, alpha=.3) +
    geom_ribbon(data=sds.cheby.right, aes(x=x, ymin=0, ymax=y),
                fill=pink, alpha=.3) +
    geom_line(data=sds.cheby.curve, aes(x=x, y=y), color=green, linewidth=1.2) +
    geom_vline(xintercept=c(-sds.cheby.k, sds.cheby.k), color="gray60",
               linetype="dotted", linewidth=.8) +
    scale_x_continuous(breaks=c(-sds.cheby.k, 0, sds.cheby.k), labels=ticks) +
    scale_y_continuous(breaks=NULL) +
    coord_cartesian(xlim=c(-5, 5), ylim=c(0, sds.cheby.top + .02)) +
    simplified.theme
}

# Chebyshev hint + nonnegative counterexample figures: writer-free transfer.
# Session must already hold: zvar.dots (id, z), teal, pink, green,
# simplified.theme, ggplot2 attached. Defines cheby.blue/alpha plus
# seven zero-arg paired-figure FUNCTIONS (call each with ()); draws on
# the active graphics device (no writers). Staged call sites:
# nonneg.fig(), cheby.z.fig(), cheby.abs.fig(), cheby.z2.fig(),
# cheby.reference.fig(), cheby.step.fig(), cheby.ramp.fig(). Pairs are
# 9x3.3 at print time: LEFT dots by original id, RIGHT probability
# histogram with dots (reference: 3 states across, dots over hists).

cheby.blue = "blue"  # indicator-region blue, Markov/homework match
cheby.alpha = .1  # unit indicator alpha; ramp scales .1*value/.5625
cheby.gray = "gray70"  # zero observations: dots and bar contributions
cheby.xlim = c(-1.75, 2.5)  # common value range, all panels/figures
cheby.ylim.hist = c(0, .46)  # shared histogram range (zvar.base grammar)
cheby.barw = .2  # zvar bar width; t=.75/.5625 cutoffs fall in bar gaps

# Signed-origin color persists across the fold/square flip: negatives
# teal, positives pink, zeros gray. Dots keep id, x, and color; only
# the plotted value moves.
cheby.origin = function(z) {
  ifelse(z < 0, teal, ifelse(z > 0, pink, cheby.gray))
}

# One figure's data from the shared dots. `value` is per-id plotted
# values (z, abs(z), or z^2); `event` the per-id logical event vector.
cheby.data = function(value, event) {
  d = data.frame(id=zvar.dots$id, z=zvar.dots$z, v=value, event=event,
                 col=cheby.origin(zvar.dots$z))
  d = d[order(d$id), ]  # id order first: every rank below is id rank
  # LEFT x: spread once by original abs(z) group across 0..241; same
  # per-id x through every state, separating each squared-value row.
  d$arank = ave(d$id, abs(d$z), FUN=function(x) seq_along(x))
  d$acount = ave(d$id, abs(d$z), FUN=length)
  d$spreadx = 241*(d$arank - .5)/d$acount
  # RIGHT stacks: two dot columns (v+.05, v+.15) alternating down each
  # color segment, rows centered at base+(row-.5)*2/20. Singleton
  # segments (2.25: one pink, one teal) stack vertically at one x.
  d$cidx = ave(d$id, d$v, d$col, FUN=function(x) seq_along(x))
  n.pink = tapply(d$col == pink, d$v, sum)
  d$stack = (ifelse(d$col == teal, n.pink[as.character(d$v)], 0) +
             ((d$cidx + 1) %/% 2 - .5)*2)/nrow(d)
  d$bin = d$v + ifelse(d$cidx %% 2 == 1, .05, .15)
  # Pale sign colors for hollow zero-area markers.
  d$pale = vapply(d$col, function(cc) adjustcolor(cc, alpha.f=.4),
                  character(1))
  d
}

# Stacked bar segments per value bin: pink (right-origin) bottom, teal
# (mirrored left-origin) stacked on top; zero bin solid gray. Returns
# rect rows; no bin ever mixes in/out-of-event membership (checked).
cheby.bars = function(d) {
  bins = sort(unique(d$v))
  out = data.frame(x=numeric(0), ymin=numeric(0), ymax=numeric(0),
                   fill=character(0), stringsAsFactors=FALSE)
  for (b in bins) {
    g = d[d$v == b, ]
    n.pink = sum(g$col == pink)
    n.teal = sum(g$col == teal)
    n.gray = sum(g$col == cheby.gray)
    y = 0
    # Bar fills at alpha .3 (zvar grammar); dots stay opaque so they
    # read against their own segment. Border stays solid gray70.
    if (n.gray > 0) {
      h = n.gray/nrow(d)
      out[nrow(out) + 1, ] = list(b, y, y + h,
                                  adjustcolor(cheby.gray, alpha.f=.3))
      y = y + h
    }
    if (n.pink > 0) {
      h = n.pink/nrow(d)
      out[nrow(out) + 1, ] = list(b, y, y + h,
                                  adjustcolor(pink, alpha.f=.3))
      y = y + h
    }
    if (n.teal > 0) {
      h = n.teal/nrow(d)
      out[nrow(out) + 1, ] = list(b, y, y + h,
                                  adjustcolor(teal, alpha.f=.3))
      y = y + h
    }
  }
  out
}

# Value-axis breaks: numerics plus cutoff ticks labeled t/t^2.
cheby.breaks = function(cuts, cutlabs) {
  b = sort(unique(c(seq(-1.5, 2.5, .5), cuts)))
  lab = as.character(b)
  lab[match(cuts, b)] = cutlabs
  list(breaks=b, labels=lab)
}

# Indicator bands as background rects spanning a panel.
cheby.band.left = function(bands) {
  do.call(rbind, lapply(bands, function(bd) data.frame(
    xmin=0, xmax=241, ymin=bd[1], ymax=bd[2])))
}
cheby.band.right = function(bands) {
  do.call(rbind, lapply(bands, function(bd) data.frame(
    xmin=bd[1], xmax=bd[2], ymin=0, ymax=cheby.ylim.hist[2])))
}

# Background shade as rect data with per-rect alpha. Accepts a band
# list (uniform indicator alpha .18) or a ready data frame (ramp).
cheby.shade.df = function(bands, horizontal) {
  if (is.data.frame(bands)) return(bands)
  r = if (horizontal) cheby.band.left(bands) else cheby.band.right(bands)
  r$alpha = cheby.alpha
  r
}

# Ramp shade: alpha .1*value/.5625 in thin slices over values >= 0
# (nothing below 0). Matches the step shade exactly at the cutoff
# (normalized ramp value 1); grows unclipped above (max .4 at 2.25).
cheby.ramp.df = function(horizontal, n=80) {
  edges = seq(0, cheby.xlim[2], length.out=n + 1)
  mids = (edges[-(n + 1)] + edges[-1])/2
  a = cheby.alpha*mids/.5625
  if (horizontal)
    data.frame(xmin=0, xmax=241, ymin=edges[-(n + 1)], ymax=edges[-1],
               alpha=a)
  else
    data.frame(xmin=edges[-(n + 1)], xmax=edges[-1], ymin=0,
               ymax=cheby.ylim.hist[2], alpha=a)
}

# Dot layers: ONE unit S=.6, stroke 0, opaque sign colors on every
# ordinary/weighted layer in both panels, so unit-area dots never grow
# at the equality. Weighted layers add pale hollow zero markers (same
# S, thin stroke) preserving reference positions.
cheby.dot.layers = function(area, S=2) {
  if (is.null(area))
    return(list(geom_point(aes(color=I(col)), size=S, stroke=0,
                            shape=16)))
  list(
    geom_point(aes(color=I(col)), size=S*sqrt(area), shape=16,
               stroke=0),
    geom_point(aes(color=I(pale)), shape=21, fill=NA, size=S,
               stroke=.2,
               data=function(d) d[d$a == 0, , drop=FALSE])
  )
}

# Same, for histogram panels (dots ride the within-bin stacks).
cheby.dot.layers.stack = function(area, S=2) {
  if (is.null(area))
    return(list(geom_point(aes(y=stack, color=I(col)), size=S,
                            stroke=0, shape=16)))
  list(
    geom_point(aes(y=stack, color=I(col)), size=S*sqrt(area),
               shape=16, stroke=0),
    geom_point(aes(y=stack, color=I(pale)), shape=21, fill=NA,
               size=S, stroke=.2,
               data=function(d) d[d$a == 0, , drop=FALSE])
  )
}

cheby.left = function(d, bands, br, vlab, area=NULL, S=2) {
  if (!is.null(area)) d$a = area
  ggplot(d, aes(x=spreadx, y=v)) +
    geom_rect(data=cheby.shade.df(bands, TRUE),
              aes(xmin=xmin, xmax=xmax, ymin=ymin, ymax=ymax,
                  alpha=I(alpha)),
              inherit.aes=FALSE, fill=cheby.blue) +
    cheby.dot.layers(area, S) +
    geom_hline(yintercept=mean(d$v), color=green, linewidth=1) +
    scale_x_continuous(limits=c(0, 241), breaks=NULL) +
    scale_y_continuous(limits=cheby.xlim, breaks=br$breaks,
                       labels=br$labels) +
    labs(x="observations", y=vlab) +
    simplified.theme +
    ggplot2::theme(axis.title.x=ggplot2::element_text(colour="#aaaaaa"),
                   axis.title.y=ggplot2::element_text(colour="#aaaaaa",
                                                      angle=90))
}

cheby.right = function(d, bands, br, vlab, area=NULL, S=2) {
  if (!is.null(area)) d$a = area
  bars = cheby.bars(d)
  ggplot(d, aes(x=bin)) +
    geom_rect(data=cheby.shade.df(bands, FALSE),
              aes(xmin=xmin, xmax=xmax, ymin=ymin, ymax=ymax,
                  alpha=I(alpha)),
              inherit.aes=FALSE, fill=cheby.blue) +
    geom_rect(data=bars, aes(xmin=x, xmax=x + cheby.barw,
                             ymin=ymin, ymax=ymax, fill=I(fill)),
              inherit.aes=FALSE, color="gray70", linewidth=.4) +
    cheby.dot.layers.stack(area, S) +
    geom_vline(xintercept=mean(d$v), color=green, linewidth=1) +
    scale_x_continuous(limits=cheby.xlim, breaks=br$breaks,
                       labels=br$labels) +
    scale_y_continuous(limits=cheby.ylim.hist) +
    labs(x=vlab, y="proportion") +
    simplified.theme +
    ggplot2::theme(axis.title.x=ggplot2::element_text(colour="#aaaaaa"),
                   axis.title.y=ggplot2::element_text(colour="#aaaaaa",
                                                      angle=90))
}

# Each figure below returns one ggplot: the histogram panel. The separate
# observations panel was dropped on 2026-10-04 — the histogram carries the
# same dots and their distribution (Skip: "the histogram plot shows the
# observations"), so it stands alone. Panels are never stitched onto one
# device; a composite renders as a single flat image.

# Counterexample: mean 0 while P(Z>=1)=3/20. Threshold 1 kept.
nonneg.fig = function() {
  d = cheby.data(zvar.dots$z, zvar.dots$z >= 1)
  br = cheby.breaks(numeric(0), character(0))
  cheby.right(d, list(c(1, 2.5)), br, "Z")
}

# Hint state 1: signed positions, two-tail event |Z|>=.75.
cheby.z.fig = function() {
  d = cheby.data(zvar.dots$z, abs(zvar.dots$z) >= .75)
  br = cheby.breaks(c(-.75, .75), c("-t", "t"))
  bands = list(c(-1.75, -.75), c(.75, 2.5))
  cheby.right(d, bands, br, "Z")
}

# Hint state 2: absolute distance; teal left mass mirrored onto pink,
# stacked keeping colors. Event |Z|>=.75, same 6 observations.
cheby.abs.fig = function() {
  d = cheby.data(abs(zvar.dots$z), abs(zvar.dots$z) >= .75)
  br = cheby.breaks(.75, "t")
  bands = list(c(.75, 2.5))
  cheby.right(d, bands, br, "|Z|")
}

# Thinned value ticks for the 3-column overview: cutoffs plus integers
# not within .4 of any cutoff.
cheby.thin = function(br, cuts) {
  iscut = br$breaks %in% cuts
  isint = br$breaks == round(br$breaks)
  near = vapply(br$breaks, function(b) min(abs(b - cuts)), numeric(1))
  keep = iscut | (isint & near >= .4)
  list(breaks=br$breaks[keep], labels=br$labels[keep])
}

# Static overview: the three hint states' histograms side by side
# (Z, |Z|, Z^2). Same values, colors, thresholds; ticks thinned to
# integers + cutoffs.
cheby.reference.fig = function() {
  dz = cheby.data(zvar.dots$z, abs(zvar.dots$z) >= .75)
  da = cheby.data(abs(zvar.dots$z), abs(zvar.dots$z) >= .75)
  d2 = cheby.data(zvar.dots$z^2, zvar.dots$z^2 >= .5625)
  bz = cheby.thin(cheby.breaks(c(-.75, .75), c("-t", "t")), c(-.75, .75))
  ba = cheby.thin(cheby.breaks(.75, "t"), .75)
  b2 = cheby.thin(cheby.breaks(.5625, "t²"), .5625)
  list(Z=cheby.right(dz, list(c(-1.75, -.75), c(.75, 2.5)), bz, "Z"),
       absZ=cheby.right(da, list(c(.75, 2.5)), ba, "|Z|"),
       sq=cheby.right(d2, list(c(.5625, 2.5)), b2, "Z²"))
}

# Visual-solution state 1: indicator as dot areas 0/1 on the squared
# geometry; binary step shade; hollow zero markers hold positions.
cheby.step.fig = function() {
  d = cheby.data(zvar.dots$z^2, zvar.dots$z^2 >= .5625)
  br = cheby.breaks(.5625, "t²")
  keep = br$breaks != .5
  br = list(breaks=br$breaks[keep], labels=br$labels[keep])
  bands = list(c(.5625, 2.5))
  area = as.numeric(d$event)
  cheby.right(d, bands, br, "Z²", area=area)
}

# Visual-solution state 2: ramp dot areas value/.5625 with matching
# ramp background shade; bars identical, no renormalization.
cheby.ramp.fig = function() {
  d = cheby.data(zvar.dots$z^2, zvar.dots$z^2 >= .5625)
  br = cheby.breaks(.5625, "t²")
  keep = br$breaks != .5
  br = list(breaks=br$breaks[keep], labels=br$labels[keep])
  area = d$v/.5625
  cheby.right(d, cheby.ramp.df(FALSE), br, "Z²", area=area)
}

# Hint state 3: squared distance; same 6 in Z^2>=.5625, tail mass kept.
cheby.z2.fig = function() {
  d = cheby.data(zvar.dots$z^2, zvar.dots$z^2 >= .5625)
  br = cheby.breaks(.5625, "t²")
  keep = br$breaks != .5  # .5 would collide with the t^2 tick
  br$breaks = br$breaks[keep]
  br$labels = br$labels[keep]
  bands = list(c(.5625, 2.5))
  cheby.right(d, bands, br, "Z²")
}

library(ggplot2)

# Plot helper only. All statistical work lives in visible intcomp-calc.
# No legend is drawn on the plot: the slide text beside each figure carries
# the pink/teal key in matching colors.
intcomp.plot = function(estimator) {
  stopifnot(estimator %in% c("binomial", "hypergeometric"))
  if (estimator == "binomial") {
    samples = intcomp.samples.binom
    hw.exact = intcomp.hw.exact.binom
    hw.cheb = intcomp.hw.cheb.binom
  } else {
    samples = intcomp.samples.hyper
    hw.exact = intcomp.hw.exact.hyper
    hw.cheb = intcomp.hw.cheb.hyper
  }
  exact = with_annotations(samples, estimand=intcomp.theta,
    height=1, dots=100, highlight.dots=1, interval.width=2*hw.exact,
    vline.alpha=NA, seed=default.seed)
  guaranteed = with_annotations(samples,
    height=1, dots=100, highlight.dots=1, interval.width=2*hw.cheb,
    vline.alpha=NA, seed=default.seed)
  exact[[3]]$data$y = exact[[3]]$data$y - .0015
  guaranteed[[3]]$data$y = guaranteed[[3]]$data$y + .0015
  exact[[3]]$data$color[1] = pink
  guaranteed[[3]]$data$color[1] = teal
  limits = range(c(intcomp.samples.binom[1:100]-intcomp.hw.cheb.binom,
                   intcomp.samples.binom[1:100]+intcomp.hw.cheb.binom,
                   intcomp.samples.hyper[1:100]-intcomp.hw.cheb.hyper,
                   intcomp.samples.hyper[1:100]+intcomp.hw.cheb.hyper))
  ggplot() + guaranteed + exact +
    coord_cartesian(xlim=limits+c(-.005,.005), ylim=c(0,1.01)) +
    scale_y_continuous(breaks=NULL) +
    labs(x=NULL, y=NULL) +
    simplified.theme
}
