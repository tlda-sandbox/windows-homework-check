# Highlight backplates for kable cells. Teal matches RV's #E0F2F7 exactly;
# pink is the analogous light family color.
inds.pink.bg = "#FCE4EC"
inds.teal.bg = "#E0F2F7"

# Joint histogram: RV geom_tile grammar (probability fill scale) with the
# existing opposite stripe overlays reused as-is (same boxes, segments,
# outlines; compatible because this plot keeps coord_fixed + y-reverse).
# No per-cell labels: exact values live in the table beside it, as in RV.
inds.joint.fig = function(mech, state) {
  stopifnot(mech %in% c("with", "without"), state %in% 0:3)
  pcol = if (mech == "with") "p_with" else "p_without"
  show.row = state %in% c(1, 3)
  show.col = state %in% c(2, 3)
  p = ggplot(indrev.grid, aes(x=J2, y=J1, fill=.data[[pcol]])) +
    geom_tile(color="gray70", linewidth=.6) +  # gray grid, not RV white:
    # without-replacement zero cells are white-filled and would vanish
    # against the background with white borders
    scale_y_reverse(breaks=1:4) +
    scale_fill_gradient(low="white", high="#7756a8", limits=c(0, 1/12),
                        breaks=c(0, 1/16, 1/12),
                        labels=c("0", "1/16", "1/12"),
                        name="P(J1,J2)") +
    coord_fixed() +
    labs(x="J2 (second person)", y="J1 (first person)") +
    simplified.theme
  if (show.row)
    p = p +
      geom_segment(data=indrev.rowstripes,
                   aes(x=x, y=y, xend=xend, yend=yend), inherit.aes=FALSE,
                   color=pink, linewidth=.5, alpha=.75) +
      annotate("rect", xmin=indrev.rowbox$x0, xmax=indrev.rowbox$x1,
               ymin=indrev.rowbox$y0, ymax=indrev.rowbox$y1,
               fill=NA, color=pink, linewidth=1)
  if (show.col)
    p = p +
      geom_segment(data=indrev.colstripes,
                   aes(x=x, y=y, xend=xend, yend=yend), inherit.aes=FALSE,
                   color=teal, linewidth=.5, alpha=.75) +
      annotate("rect", xmin=indrev.colbox$x0, xmax=indrev.colbox$x1,
               ymin=indrev.colbox$y0, ymax=indrev.colbox$y1,
               fill=NA, color=teal, linewidth=1)
  if (state == 3)
    p = p + annotate("rect", xmin=indrev.sc - .5, xmax=indrev.sc + .5,
                     ymin=indrev.sr - .5, ymax=indrev.sr + .5,
                     fill=NA, color="gray30", linewidth=.8)
  p
}

# Marginal histograms: both draws' true marginals in every state (all 1/4),
# faceted so J1 versus J2 is explicit; fills track the selection. No
# conditioning, no renormalization, no invented distribution.
inds.marg.data = data.frame(
  draw=rep(c("J1", "J2"), each=4),
  person=rep(1:4, times=2),
  p=1/4, lab="1/4")
inds.marg.fig = function(mech, state) {
  stopifnot(mech %in% c("with", "without"), state %in% 0:3)
  show.row = state %in% c(1, 3)
  show.col = state %in% c(2, 3)
  d = inds.marg.data
  d$fill = "gray70"
  d$fill[d$draw == "J1" & d$person == indrev.sr & show.row] = pink
  d$fill[d$draw == "J2" & d$person == indrev.sc & show.col] = teal
  ggplot(d, aes(x=factor(person), y=p, fill=I(fill))) +
    geom_col() +
    facet_wrap(~draw, labeller=labeller(
      draw=c(J1="J1 (first person)", J2="J2 (second person)"))) +
    scale_y_continuous(limits=c(0, .32), breaks=(0:3)/10) +
    labs(x="person", y="probability") +
    simplified.theme
}

# Joint probability table: RV kable grammar. Values from the same
# indrev.grid label columns; row/column backplates match the stripes.
# State 3: the selected intersection cell carries BOTH colors as layered
# opposing CSS stripes (cell-local style, no new package or global CSS).
inds.crosshatch.css = paste(
  "repeating-linear-gradient(45deg, #FCE4EC 0 3px, transparent 3px 6px),",
  "repeating-linear-gradient(-45deg, #E0F2F7 0 3px, transparent 3px 6px),",
  "white")
inds.joint.tab = function(mech, state) {
  stopifnot(mech %in% c("with", "without"), state %in% 0:3)
  lcol = if (mech == "with") "lab_with" else "lab_without"
  m = matrix(indrev.grid[[lcol]], nrow=4)  # expand.grid: J1 fastest
  tab = data.frame(J1=1:4, `J2 = 1`=m[, 1], `J2 = 2`=m[, 2],
                   `J2 = 3`=m[, 3], `J2 = 4`=m[, 4],
                   `Row sum`="1/4", check.names=FALSE)
  k = knitr::kable(tab, format="html", align="c")
  if (state %in% c(1, 3))
    k = kableExtra::row_spec(k, indrev.sr, background=inds.pink.bg, bold=TRUE)
  if (state %in% c(2, 3))
    k = kableExtra::column_spec(k, indrev.sc + 1,
                                background=inds.teal.bg, bold=TRUE)
  if (state == 3) {
    h = paste(as.character(k), collapse="\n")
    parts = strsplit(h, "<tr>", fixed=TRUE)[[1]]
    stopifnot(length(parts) == 6)  # pre + header + 4 body rows
    target = 2 + indrev.sr
    teal.token = "background-color: rgba(224, 242, 247, 1) !important;"
    occ = gregexpr(teal.token, parts[target], fixed=TRUE)[[1]]
    stopifnot(length(occ) == 1L && occ[1] > 0)  # exactly the one cell
    parts[target] = sub(teal.token,
      paste0("background: ", inds.crosshatch.css, " !important;"),
      parts[target], fixed=TRUE)
    k = knitr::asis_output(paste(parts, collapse="<tr>"))
  }
  knitr::asis_output(paste(as.character(k), collapse="\n"))
}

# Marginal probability table: both draws' marginals side by side; the two
# selected cells highlight independently, matching the histogram fills.
inds.marg.tab = function(mech, state) {
  stopifnot(mech %in% c("with", "without"), state %in% 0:3)
  show.row = state %in% c(1, 3)
  show.col = state %in% c(2, 3)
  j1 = rep("1/4", 4)
  j2 = rep("1/4", 4)
  if (show.row)
    j1[indrev.sr] = kableExtra::cell_spec("1/4", background=inds.pink.bg,
                                          bold=TRUE)
  if (show.col)
    j2[indrev.sc] = kableExtra::cell_spec("1/4", background=inds.teal.bg,
                                          bold=TRUE)
  tab = data.frame(Person=1:4, J1=j1, J2=j2, check.names=FALSE)
  knitr::kable(tab, format="html", align="c", escape=FALSE)
}

slice.vmax = 1/12*1.28
slice.span = 2.0
slice.y0 = 6.6   # bottom-strip zero line (data y; reversed axis)
slice.x0 = 4.6   # right-strip zero line (data x)
slice.ypos = function(v) slice.y0 - v*slice.span/slice.vmax
slice.xpos = function(v) slice.x0 + v*slice.span/slice.vmax
slice.axis.v = c(0, 1/16, 1/12)
slice.axis.lab = c("0", "1/16", "1/12")

# Composite slice figure. slice "none"/"row"/"col" selects the highlight;
# pos is the explicit selected index 1:4 (row or column position; NULL
# keeps the legacy indrev.sr/sc positions). bars=TRUE draws that slice's
# raw joint values in its strip (bottom for "row", right for "col").
# Identical scales/limits/breaks/legend across all calls, so the grid
# never moves between fragment states.
inds.slice.fig = function(mech, slice=c("none", "row", "col"), bars=FALSE,
                          pos=NULL) {
  stopifnot(mech %in% c("with", "without"))
  slice = match.arg(slice)
  if (is.null(pos)) pos = if (slice == "col") indrev.sc else indrev.sr
  stopifnot(pos %in% 1:4)
  pcol = if (mech == "with") "p_with" else "p_without"
  show.row = slice == "row"
  show.col = slice == "col"
  title = if (mech == "with") "With replacement" else "Without replacement"
  p = ggplot(indrev.grid, aes(x=J2, y=J1, fill=.data[[pcol]])) +
    geom_tile(color="gray70", linewidth=.6) +
    scale_x_continuous(breaks=c(1:4, slice.xpos(slice.axis.v)),
                       labels=c("1", "2", "3", "4", slice.axis.lab),
                       limits=c(0.4, 6.9)) +
    scale_y_reverse(breaks=c(1:4, slice.ypos(slice.axis.v)),
                    labels=c("1", "2", "3", "4", slice.axis.lab),
                    limits=c(6.9, 0.4)) +
    scale_fill_gradient(low="white", high="#7756a8", limits=c(0, 1/12),
                        breaks=c(0, 1/16, 1/12),
                        labels=c("0", "1/16", "1/12"),
                        name="P(J1, J2)") +
    coord_fixed() +
    labs(title=title, x="J2 (second person)", y="J1 (first person)") +
    simplified.theme
  if (show.row) {
    rb = list(x0=.5, x1=4.5, y0=pos - .5, y1=pos + .5)
    rs = indrev.hatch(rb$x0, rb$x1, rb$y0, rb$y1, "up")
    p = p +
      geom_segment(data=rs,
                   aes(x=x, y=y, xend=xend, yend=yend), inherit.aes=FALSE,
                   color=pink, linewidth=.5, alpha=.75) +
      annotate("rect", xmin=rb$x0, xmax=rb$x1,
               ymin=rb$y0, ymax=rb$y1,
               fill=NA, color=pink, linewidth=1)
  }
  if (show.col) {
    cb = list(x0=pos - .5, x1=pos + .5, y0=.5, y1=4.5)
    cs = indrev.hatch(cb$x0, cb$x1, cb$y0, cb$y1, "down")
    p = p +
      geom_segment(data=cs,
                   aes(x=x, y=y, xend=xend, yend=yend), inherit.aes=FALSE,
                   color=teal, linewidth=.5, alpha=.75) +
      annotate("rect", xmin=cb$x0, xmax=cb$x1,
               ymin=cb$y0, ymax=cb$y1,
               fill=NA, color=teal, linewidth=1)
  }
  if (bars && show.row) {
    d = indrev.grid[indrev.grid$J1 == pos, ]
    d = d[order(d$J2), ]
    p = p + geom_rect(
      data=data.frame(xmin=d$J2 - .4, xmax=d$J2 + .4,
                      ymin=slice.ypos(d[[pcol]]), ymax=slice.y0),
      aes(xmin=xmin, xmax=xmax, ymin=ymin, ymax=ymax),
      inherit.aes=FALSE, fill=pink)
  }
  if (bars && show.col) {
    d = indrev.grid[indrev.grid$J2 == pos, ]
    d = d[order(d$J1), ]
    p = p + geom_rect(
      data=data.frame(xmin=slice.x0, xmax=slice.xpos(d[[pcol]]),
                      ymin=d$J1 - .4, ymax=d$J1 + .4),
      aes(xmin=xmin, xmax=xmax, ymin=ymin, ymax=ymax),
      inherit.aes=FALSE, fill=teal)
  }
  p
}

# One-image sweep state: with- and without-replacement plots for one
# selected row/column, printed side by side onto a single device.
# Mechanics mirror cheby.draw (grid viewports, no new dependencies);
# the two panels are the same objects inds.slice.fig returns.
inds.slice.pair = function(slice=c("row", "col"), pos) {
  slice = match.arg(slice)
  stopifnot(length(pos) == 1, pos %in% 1:4)
  left = inds.slice.fig("with", slice, TRUE, pos)
  right = inds.slice.fig("without", slice, TRUE, pos)
  grid::grid.newpage()
  grid::pushViewport(grid::viewport(layout=grid::grid.layout(
    1, 2, widths=grid::unit(c(1, 1), "null"))))
  print(left, vp=grid::viewport(layout.pos.row=1, layout.pos.col=1))
  print(right, vp=grid::viewport(layout.pos.row=1, layout.pos.col=2))
  grid::popViewport()
  invisible(list(with=left, without=right))
}

means.response.colors = c("00"="#eadff1", "01"="#dbeef5",
                         "10"="#f9e0e7", "11"="#dff0df")
means.call.data = function(population, scheme, third=NULL) {
  stopifnot(length(population) == 4, all(population %in% 0:1),
            scheme %in% c("with", "without"))
  d = expand.grid(J1=1:4, J2=1:4)
  d$Y1 = population[d$J1]
  d$Y2 = population[d$J2]
  d$group = paste0(d$Y1, d$Y2)
  d$response = d$group
  possible = d$J1 != d$J2
  denominator = if (scheme == "with") 16 else 12
  if (!is.null(third)) {
    stopifnot(length(third) == 1, third %in% 1:4)
    d$response = paste0(d$response, population[third])
    possible = possible & d$J1 != third & d$J2 != third
    denominator = if (scheme == "with") 64 else 24
  }
  d$p = if (scheme == "with") rep(1/denominator, nrow(d))
        else ifelse(possible, 1/denominator, 0)
  d$probability = ifelse(d$p == 0, "0", paste0("1/", denominator))
  d
}
means.call.fig = function(population, scheme, third=NULL,
                          selected.call=NULL, selected.person=NULL) {
  d = means.call.data(population, scheme, third)
  p = ggplot(d, aes(x=J2, y=J1)) +
    geom_tile(aes(fill=group), color="white", linewidth=.7) +
    scale_fill_manual(values=means.response.colors, guide="none") +
    geom_text(aes(label=paste0(probability, "\n", response)),
              size=3.6, lineheight=1.1, color="gray20") +
    scale_x_continuous(breaks=1:4, limits=c(.5,4.5), expand=c(0,0)) +
    scale_y_reverse(breaks=1:4, limits=c(4.5,.5), expand=c(0,0)) +
    coord_fixed() +
    labs(x="Second person called", y="First person called") +
    simplified.theme
  if (!is.null(selected.call)) {
    stopifnot(selected.call %in% 1:2, selected.person %in% 1:4)
    if (selected.call == 1) {
      p = p + annotate("rect", xmin=.5, xmax=4.5,
        ymin=selected.person-.5, ymax=selected.person+.5,
        fill=NA, color=pink, linewidth=1.2)
    } else {
      p = p + annotate("rect", xmin=selected.person-.5,
        xmax=selected.person+.5, ymin=.5, ymax=4.5,
        fill=NA, color=teal, linewidth=1.2)
    }
  }
  p
}
means.call.table = function(population) {
  with = means.call.data(population, "with")
  without = means.call.data(population, "without")
  order = order(with$group, with$J1, with$J2)
  d = data.frame(
    J1=with$J1, J2=with$J2, Y1=with$Y1, Y2=with$Y2,
    `With replacement`=with$probability,
    `Without replacement`=without$probability,
    check.names=FALSE)[order,]
  rownames(d) = NULL
  tab = knitr::kable(d, format="html", align="c")
  for (i in seq_len(nrow(d)))
    tab = kableExtra::row_spec(tab, i,
      background=means.response.colors[[with$group[order[i]]]])
  knitr::asis_output(paste(as.character(tab), collapse="\n"))
}
